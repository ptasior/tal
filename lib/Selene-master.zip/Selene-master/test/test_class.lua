bar = Bar.new(8)
barx = bar:get_x()
barp = bar:print(2)
